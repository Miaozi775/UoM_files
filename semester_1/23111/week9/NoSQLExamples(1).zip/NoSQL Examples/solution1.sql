{
	_id: "8492365",
	name: "Teddy Becca"
	course:{
		degree: "Computer Science",
		division: "Computing",
		school: "Computer Science",
		faculty: "Faculty of Science and Engineering",
		university: "University of Manchester"
	}
}