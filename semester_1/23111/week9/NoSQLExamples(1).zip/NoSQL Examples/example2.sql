{
	_id: "8492365",
	name: "Teddy Becca"
}

{
	student_id: "8492365",
	degree: "Computer Science",
	division: "Computing",
	school: "Computer Science",
	faculty: "Faculty of Science and Engineering",
	university: "University of Manchester"
}

{
	student_id: "8492365",
	degree: "Business",
	division: "Management Science and Marketing",
	school: "AMBS",
	faculty: "Humanities",
	university: "University of Manchester"
}