{
	title: "MongoDB: The Definitive Guide",
	author: [ "Kristina Chodorow", "Mike Dirolf" ],
	published_date: ISODate("2010-09-24"),
	pages: 216,
	language: "English",
	publisher: {
		name: "O'Reilly Media",
		founded: 1980,
		location: "CA"
	}
}

{
	title: "50 Tips and Tricks for MongoDB Developer",
	author: "Kristina Chodorow",
	published_date: ISODate("2011-05-06"),
	pages: 68,
	language: "English",
	publisher: {
		name: "O'Reilly Media",
		founded: 1980,
		location: "CA"
	}
}